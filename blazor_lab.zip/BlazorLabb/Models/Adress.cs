﻿namespace BlazorLabb.Models
{
    public class Adress
    {
        public string? Street { get; set; }
        public string? ZipCode { get; set; }
        public string? City { get; set; }
    }
}
