﻿namespace BlazorLabb.Models
{
    public class Company
    {
        public string? Name { get; set; }
        public string? CatchPhrase { get; set; }
    }
}
